﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using $safeprojectname$.Authorization.Policies;
using $safeprojectname$.Communication.Mail;
using $safeprojectname$.Communication.Utilities;
using $safeprojectname$.Data.Context;
using $safeprojectname$.Data.Context.Identity;
using $safeprojectname$.Data.IRepository;
using $safeprojectname$.Data.Repository.GenericRepository;
using $safeprojectname$.Services.Generic;
using $safeprojectname$.Services.IServices;
using $safeprojectname$.Services.IServices.Identity;
using $safeprojectname$.Services.Services;
using $safeprojectname$.Services.Services.Identity;

namespace $safeprojectname$.Extensions
{
    /// <summary>
    /// Services injection resolver
    /// </summary>
    public static class ApplicationServicesExtension
    {
        /// <summary>
        /// Add services for injection
        /// </summary>
        /// <param name="services"></param>
        /// <returns></returns>
        public static IServiceCollection AddServices(this IServiceCollection services)
        {
            services.AddTransient<DataContext, DataContext>();
            services.AddTransient<AppIdentityContext, AppIdentityContext>();
            
            services.AddTransient(typeof(IGenericDataRepository<>), typeof(GenericDataRepository<>));
            services.AddTransient(typeof(GenericDataRepository<>), typeof(GenericDataRepository<>));

            services.AddScoped<SaveFormFileSerivce, SaveFormFileSerivce>();
            services.AddScoped<SendOTPService, SendOTPService>();
            services.AddScoped<IManageService, ManageService>();
            services.AddScoped<IRoleActionsService, RoleActionsService>();
            services.AddScoped<IUserService, UserService>();
            services.AddScoped<ISignInService, SignInService>();
            services.AddScoped<IRoleService, RoleService>();
            services.AddScoped<EmailFunctions, EmailFunctions>();
            services.AddScoped<EmailHelperCore, EmailHelperCore>();


            services.AddScoped<IAuthorizationHandler, CustomRequireClaimHandler>();
            services.AddScoped<IAuthorizationHandler, CustomRequirePolicyHandler>();

            services.AddSingleton<IExceptionLogginService, ExceptionLogginService>();

            return services;
        }
    }
}
