﻿using $safeprojectname$.Data.Entities.Identity;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Data.Context.Identity
{
    public class DataContextSeed
    {
        public static async Task SeedAsync(DataContext services)
        {
            
        }
    }
}
